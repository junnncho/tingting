import { Env } from "./envType";
export const env: Env = {
  environment: "main",
  networkType: "mainnet",
  cloudflare: {
    siteKey: "0x4AAAAAAABemYrHFpNbI5n_",
  },
} as const;
