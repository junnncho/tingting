import { Env } from "./envType";
import { env as testing } from "./env.testing";
export const env = {
  ...testing,
  environment: "testing.local",
  origin: "https://mountingting.com",
  endpoint: "https://mountingting.com:8080/backend/graphql",
  ws: "https://mountingting.com:1234",
  cloudflare: {
    siteKey: "1x00000000000000000000AA",
  },
};
