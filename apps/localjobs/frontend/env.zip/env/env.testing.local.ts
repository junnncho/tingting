import { Env } from "./envType";
import { env as debug } from "./env.debug";
export const env: Env = {
  ...debug,
  environment: "debug.local",
  origin: "http://localhost:4200",
  endpoint: "http://localhost:8080/backend/graphql",
  ws: "http://localhost:1234",
  cloudflare: {
    siteKey: "1x00000000000000000000AA",
  },
};
