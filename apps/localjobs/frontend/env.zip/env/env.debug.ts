import { Env } from "./envType";
export const env: Env = {
  environment: "debug",
  networkType: "debugnet",
  cloudflare: {
    siteKey: "0x4AAAAAAABsjg9f4r5hz1rS",
  },
} as const;
