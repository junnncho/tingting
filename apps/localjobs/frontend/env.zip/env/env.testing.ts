import { Env } from "./envType";
export const env: Env = {
  environment: "debug",
  networkType: "debugnet",
  cloudflare: {
    siteKey: "1x00000000000000000000AA",
  },
} as const;
