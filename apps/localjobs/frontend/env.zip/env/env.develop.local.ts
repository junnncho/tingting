import { Env } from "./envType";
import { env as develop } from "./env.develop";
export const env = {
  ...develop,
  environment: "develop.local",
  origin: "http://localhost:4200",
  endpoint: "http://localhost:8080/backend/graphql",
  ws: "http://localhost:1234",
  cloudflare: {
    siteKey: "1x00000000000000000000AA",
  },
};
